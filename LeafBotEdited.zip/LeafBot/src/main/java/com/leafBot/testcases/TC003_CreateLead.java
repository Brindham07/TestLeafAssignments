package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;


	public class TC003_CreateLead extends ProjectSpecificMethods{	

		@BeforeTest
		public void setValues() {
			testCaseName = "Create Lead";
			testDescription = "Create Lead for Leaftaps";
			nodes = "Leads";
			authors = "Brindha";
			category = "Smoke";
			dataSheetName = "TC003";
		}

		@Test(dataProvider = "fetchData")
		public void createLeaf(String uName, String pwd,String cName, String fName,String lName ) {
			new LoginPage(driver,node)
			.enterUserName(uName)
			.enterPassword(pwd)
			.clickLogin().clickCMRSFA()
			.clickLeadsTab()
			.clickCreateLead()
			.enterCompName(cName)
			.enterFirstName(fName)
			.enterLastName(lName)
			.createLeadBtn().verifyLead();
		
		}


	}

