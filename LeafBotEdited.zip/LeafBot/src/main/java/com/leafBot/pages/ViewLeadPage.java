package com.leafBot.pages;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;


public class ViewLeadPage extends ProjectSpecificMethods {
	
	public ViewLeadPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver= driver;
		this.node= node;
		PageFactory.initElements(driver,this);
	}

	public ViewLeadPage verifyLead()
	{
		System.out.println("Create Lead is Verified and Lead Created");
		return this;
	}
	
}
