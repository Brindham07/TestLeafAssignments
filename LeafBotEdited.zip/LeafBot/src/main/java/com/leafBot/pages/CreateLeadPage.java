package com.leafBot.pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods{
	public CreateLeadPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver= driver;
		this.node= node;
		PageFactory.initElements(driver,this);
	}
	
	public CreateLeadPage enterCompName(String data)
	{
	    clearAndType(locateElement("id", "createLeadForm_companyName"), data);
		return this;
	}
	
	public CreateLeadPage enterFirstName(String data)
	{
		
		 clearAndType(locateElement("id", "createLeadForm_firstName"), data);
			return this;
	}
	public CreateLeadPage enterLastName(String data)
	{
	
		clearAndType(locateElement("id", "createLeadForm_lastName"), data);
		return this;
	}
	
	
	public ViewLeadPage createLeadBtn()
	{
		click(locateElement("name", "submitButton"));
		return new ViewLeadPage(driver,node);		
	}

}
